using UnityEngine;
using System.Collections;

public class EnemyBehaviour : MonoBehaviour {

	public FSM fsm;

	// Use this for initialization
	void Start () {

		fsm = new FSM ();
	}
	
	// Update is called once per frame
	void Update () {
	
		DoByState ();
	}

	void DoByState () {

		switch (fsm.currentState) {
		case FSM.State.Patrol:
			OnPatrol();
			break;
		case FSM.State.Follow:
			OnFollow();
			break;
		case FSM.State.Attack:
			OnAttack();
			break;
		}
	}

	void OnPatrol () {

	}

	void OnFollow () {
		
	}

	void OnAttack () {
		
	}
}