using UnityEngine;
using System.Collections;

//v 1.1

public class StateMachine 
{
	int[,]FSM;
	int CurrentState = -1;
	
	public delegate void Template2State(int statePrev, int statePost);
	public event Template2State OnChangeState = delegate {};
	
	
	public StateMachine(int statesCount, int eventsCount, int initialState = -1)
	{
		// crea la matriz
		FSM = new int[statesCount, eventsCount];
		// la llena
		for(int i = 0; i < FSM.GetLength(0); i++)
		{
			for(int j = 0; j < FSM.GetLength(1); j++)
			{
				FSM[i,j] = -1;
			}
		}
		
		SetState(initialState);
	}
	
	public void SetRelation(int stateA, int stateB, int eventDesignate)
	{
		FSM[stateA, eventDesignate] = stateB;
	}
	
	public void ExecuteEvent(int eventDesignate)
	{
		/*
		Debug.Log("ExecuteEvent");
		Debug.Log(((Unity.UnityStates)CurrentState).ToString());
		Debug.Log(((Unity.UnityEvents)eventDesignate).ToString());
		Debug.Log(((Unity.UnityStates)FSM[CurrentState, eventDesignate]).ToString());
		*/
		if(FSM[CurrentState, eventDesignate] != -1)
		{
			SetState(FSM[CurrentState, eventDesignate]);
		}
	}
	
	public int GetState()
	{
		return CurrentState;	
	}
	
	public void SetState(int currentState)
	{
		int prevState = CurrentState, newState = currentState;
		
		CurrentState = currentState;
		
		OnChangeState(prevState, newState);
	}
}