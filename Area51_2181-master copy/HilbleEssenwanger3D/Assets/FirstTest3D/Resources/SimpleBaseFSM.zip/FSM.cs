using UnityEngine;
using System.Collections;

public class FSM : MonoBehaviour {

	public enum State {
		Patrol,
		Follow,
		Attack
	}

	public enum Event {
		Detect,
		LoseSight,
		InRange
	}

	private int[,] matrix;

	public State currentState;

	public FSM () {
		currentState = State.Patrol;

		this.matrix = new int[,] {
			//Patrol				Follow				Attack
			{(int) State.Follow,	-1,					-1},				//Detect
			{-1,					(int) State.Patrol,	(int) State.Patrol},//LoseSight
			{(int) State.Attack,	(int) State.Attack,	-1}					//InRange
		};
	}

	public void ExecEvent (Event smEvent) {
		int newState = this.matrix [(int)currentState, (int)smEvent];
		if (newState != -1) {
			currentState = (State) newState;
		}
	}
}